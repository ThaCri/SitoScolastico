import pandas as pd
import matplotlib.pyplot as plt

# Percorso del file
file_path = 'dati_incidenti.xlsx'

# Carica i dati
df = pd.read_excel(file_path, sheet_name='Incidenti', header=1)
df.dropna(how='all', inplace=True)

# Calcoli
numero_incidenti = len(df)
incidenti_per_mese = df['Mese'].value_counts().sort_index()
probabilita_per_mese = incidenti_per_mese / numero_incidenti

# Stampa a console
print("Probabilità di incidente per mese:")
for mese, prob in probabilita_per_mese.items():
    print(f"Mese {mese}: {prob:.2%}")

# Grafico
plt.figure(figsize=(10, 6))
bars = plt.bar(probabilita_per_mese.index, probabilita_per_mese.values, color='skyblue', edgecolor='black')

# Aggiunta percentuali sopra ogni barra
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2,
             height,
             f"{height:.1%}",
             ha='center', va='bottom', fontsize=10)

# Dettagli del grafico
plt.title('Probabilità di Incidenti per Mese')
plt.xlabel('Mese')
plt.ylabel('Probabilità (%)')
plt.xticks(probabilita_per_mese.index)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()